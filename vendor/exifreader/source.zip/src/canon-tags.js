/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

// Reverse-engineered docs:
// https://exiftool.org/makernote_types.html
// https://exiv2.org/makernote.html
// https://exiv2.org/tags-canon.html
// https://gist.github.com/redaktor/bae0ef2377ab70bc5276
// https://www.ozhiker.com/electronics/pjmt/jpeg_info/canon_mn.html

import {objectAssign} from './utils.js';
import {readIfd} from './tags-helpers.js';
import TagNamesCanonIfd from './tag-names-canon-ifd.js';
import {IFD_TYPE_CANON} from './ifd-types.js';

const SHOT_INFO_AUTO_ROTATE = 27; // First position is size.
const CAMERA_SETTINGS_LENS_TYPE = 22; // First position is size.

export default {
    read,
    SHOT_INFO_AUTO_ROTATE,
    CAMERA_SETTINGS_LENS_TYPE
};

function read(
    dataView,
    tiffHeaderOffset,
    offset,
    byteOrder,
    includeUnknown,
    computed = false,
    tagFilter = undefined,
    valueBudget = undefined
) {
    let tags = readIfd(
        dataView,
        IFD_TYPE_CANON,
        tiffHeaderOffset,
        tiffHeaderOffset + offset,
        byteOrder,
        includeUnknown,
        computed,
        tagFilter,
        'makerNotes',
        valueBudget,
        getTagNames()
    );

    if (tags['ShotInfo']) {
        tags = objectAssign({}, tags, parseShotInfo(tags['ShotInfo'].value));
        delete tags['ShotInfo'];
    }
    if (tags['CameraSettings']) {
        tags = objectAssign({}, tags, parseCameraSettings(tags['CameraSettings'].value));
        delete tags['CameraSettings'];
    }

    return tags;
}

// Assigned rather than a computed key, which Babel compiles to a helper call.
function getTagNames() {
    const tagNames = {};
    tagNames[IFD_TYPE_CANON] = TagNamesCanonIfd;
    return tagNames;
}

function parseShotInfo(shotInfoData) {
    const tags = {};

    const autoRotate = shotInfoData[SHOT_INFO_AUTO_ROTATE];
    if (Number.isFinite(autoRotate)) {
        tags['AutoRotate'] = {
            value: autoRotate,
            description: getAutoRotateDescription(autoRotate)
        };
    }

    return tags;
}

function parseCameraSettings(cameraSettingsData) {
    const tags = {};
    if (!Array.isArray(cameraSettingsData)) {
        return tags;
    }

    const lensType = cameraSettingsData[CAMERA_SETTINGS_LENS_TYPE];
    if (Number.isFinite(lensType)) {
        tags['LensType'] = {
            value: lensType,
            description: `${lensType}`
        };
    }

    return tags;
}

function getAutoRotateDescription(autoRotate) {
    if (autoRotate === 0) {
        return 'None';
    }
    if (autoRotate === 1) {
        return 'Rotate 90 CW';
    }
    if (autoRotate === 2) {
        return 'Rotate 180';
    }
    if (autoRotate === 3) {
        return 'Rotate 270 CW';
    }
    return 'Unknown';
}
